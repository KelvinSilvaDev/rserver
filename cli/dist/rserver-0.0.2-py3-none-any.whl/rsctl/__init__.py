"""
Remote Server Control (rserver) - CLI profissional para gerenciar serviços remotos
"""

__version__ = "0.0.2"
__author__ = "Remote Server Team"

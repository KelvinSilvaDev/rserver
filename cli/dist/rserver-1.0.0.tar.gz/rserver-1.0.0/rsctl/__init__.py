"""
Remote Server Control (rserver) - CLI profissional para gerenciar serviços remotos
"""

__version__ = "1.0.0"
__author__ = "Remote Server Team"
